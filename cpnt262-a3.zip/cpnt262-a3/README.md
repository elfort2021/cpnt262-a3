# cpnt262-a3

## Author: Eleanor Forte, 000841873

JSON GALLERY

### Heroku Link:

https://ass-3.herokuapp.com/
(I realize I named this ass-3. No lie, I did not even catch that until this exact moment. And now I might leave it.)

### Github Repo:

https://github.com/elfort2021/cpnt262-a3

**Shoutouts**
The Cry Club Gang, Erica Kyle and Karen.

General Notes: This is really difficult and confusing. Backend is quite frightening. But as we always say, confused and amused.

## Attributions:

- Photo by Filip Kominik (Doorways)
  https://unsplash.com/photos/IHtVbLRjTZU

- Photo by Ren Ran on Unsplash (watermelon leaves)
  https://unsplash.com/photos/bBiuSdck8tU

- Photo by Kendal on Unsplash (fiddle leaf)
  https://unsplash.com/photos/TW2bfT_tWDI

- Photo by Elsa Noblet on Unsplash (Greenhouse)
  https://unsplash.com/photos/r37oKn9cW-s

- Photo by Paula Russell (Monstera Leaf)
  https://unsplash.com/photos/8FSJjOb1nUc

- Photo by Gerome Brunaeu (Sunflowers)
  https://unsplash.com/photos/RPmWEtZLh7U

- Photo by Annie Sprat (Succulents in Pots)
  https://unsplash.com/photos/ncQ2sguVlgo

- Photo by Olena Sergienko (Fern Leaf)
  https://unsplash.com/photos/r0M9HrfJMBM

- Photo by Scott Webb (Rubber Tree)
  https://unsplash.com/photos/BLBCj6dxaSE
